package com.ssi.devicemonitor.entity;

public class GeneralDevice extends Device {
    public GeneralDevice(String name) {
        super(name);
    }
}
